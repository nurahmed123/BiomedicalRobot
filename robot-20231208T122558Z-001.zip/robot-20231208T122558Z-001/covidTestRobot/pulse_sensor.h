/********************************* pulseSensor.h ********************************************/
#ifndef __PULSE_SENSOR_H__
#define __PULSE_SENSOR_H__

void pulse_sensor_setup();
void pulse_sensor_read(int * heart_rate, int * sp02);
#endif
