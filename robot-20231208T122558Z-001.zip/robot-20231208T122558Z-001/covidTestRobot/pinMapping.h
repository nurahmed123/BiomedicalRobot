/************************************ pinMapping.h ****************************************/


//#define servo1 3
//#define servo2 4
//#define servo3 5
//#define servo4 6
//#define servo5 7




#define pumpPin 11
#define ultravioletPin 12


//#define redPin 2
//#define greenPin 4
//#define bluePin 13
